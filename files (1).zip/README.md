# Wadayaz Homepage

سادہ اسٹیٹک ویب سائٹ (HTML + CSS + JS) — کسی بھی بلڈ اسٹیپ کی ضرورت نہیں۔

## GitHub پر اپلوڈ کرنے کا طریقہ
1. GitHub پر ایک نئی repository بنائیں (مثلاً `wadayaz-website`)۔
2. اس فولڈر کی تمام فائلیں اس repository میں upload/push کر دیں۔
   ```bash
   git init
   git add .
   git commit -m "Wadayaz homepage"
   git branch -M main
   git remote add origin <آپ کے GitHub repo کا URL>
   git push -u origin main
   ```

## Vercel پر ڈیپلائے کرنے کا طریقہ
1. https://vercel.com پر جا کر GitHub اکاؤنٹ سے لاگ ان کریں۔
2. "Add New Project" پر کلک کریں اور اپنی `wadayaz-website` repository منتخب کریں۔
3. Framework Preset میں "Other" رہنے دیں (یہ خالص static سائٹ ہے، کوئی بلڈ کمانڈ درکار نہیں)۔
4. "Deploy" پر کلک کریں — چند سیکنڈز میں آپ کی سائٹ لائیو ہو جائے گی۔

## اپنی حقیقی ویڈیو اور لوگو لگانے کا طریقہ
- ویڈیو: `index.html` میں `<source src="" type="video/mp4">` والی لائن میں اپنی ویڈیو فائل کا راستہ (مثلاً `assets/promo.mp4`) ڈالیں اور فائل کو `assets` فولڈر میں رکھیں۔
- لوگو: فی الحال SVG سے ایک ملتا جلتا لوگو بنایا گیا ہے۔ اگر اصل لوگو فائل (PNG/SVG) موجود ہے تو اسے `assets/logo.svg` کے نام سے رکھیں اور `index.html` میں `<svg class="logo-mark">...` کی جگہ `<img src="assets/logo.svg" class="logo-mark" alt="Wadayaz">` استعمال کریں۔
- کمپنی لوگوز ("Trusted by" سیکشن): یہ ٹریڈ مارک لوگوز ہیں، اس لیے فی الحال ٹیکسٹ کی شکل میں دکھائے گئے ہیں۔ اگر آپ کے پاس ان کمپنیوں سے استعمال کی اجازت ہے تو ان کی اصل لوگو امیجز `assets` فولڈر میں رکھ کر HTML میں `<img>` ٹیگز سے تبدیل کر سکتے ہیں۔

## فیچرز
- گھومتا ہوا (rotating) 3D dot-matrix گلوب — کینوس/JS کے ذریعے بنایا گیا، تصویر نہیں
- گلوب کے ارد گرد فلوٹنگ بیجز (Verified, Growing, Impact, Expanding, Connected)
- اینیمیٹڈ کاؤنٹرز (500+, 1200+, 40+, 98%)
- Auto-scrolling trusted-by marquee
- ویڈیو پلے/پاز بٹن
- مکمل responsive (موبائل، ٹیبلٹ، ڈیسک ٹاپ)
- Scroll-reveal اینیمیشنز
