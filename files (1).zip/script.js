// ===================== MOBILE NAV =====================
const burgerBtn = document.getElementById('burgerBtn');
const siteHeader = document.getElementById('siteHeader');
if (burgerBtn) {
  burgerBtn.addEventListener('click', () => {
    siteHeader.classList.toggle('nav-open');
  });
}
document.querySelectorAll('.main-nav .nav-link').forEach(link => {
  link.addEventListener('click', () => siteHeader.classList.remove('nav-open'));
});

// ===================== HEADER SHADOW ON SCROLL =====================
window.addEventListener('scroll', () => {
  if (window.scrollY > 12) {
    siteHeader.style.boxShadow = '0 8px 30px -12px rgba(0,0,0,0.6)';
  } else {
    siteHeader.style.boxShadow = 'none';
  }
}, { passive: true });

// ===================== ANIMATED COUNTERS =====================
const counters = document.querySelectorAll('.counter');
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      animateCounter(entry.target);
      counterObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.4 });

function animateCounter(el) {
  const target = parseInt(el.dataset.target, 10) || 0;
  const duration = 1400;
  const start = performance.now();
  function tick(now) {
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(eased * target);
    if (progress < 1) requestAnimationFrame(tick);
    else el.textContent = target;
  }
  requestAnimationFrame(tick);
}
counters.forEach(c => counterObserver.observe(c));

// ===================== SCROLL REVEAL =====================
const revealTargets = document.querySelectorAll(
  '.about-copy, .about-video, .about-stats, .service-card, .stat-card'
);
revealTargets.forEach(el => el.classList.add('reveal'));
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in-view');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });
revealTargets.forEach(el => revealObserver.observe(el));

// ===================== VIDEO PLAY TOGGLE =====================
const playBtn = document.getElementById('playBtn');
const promoVideo = document.getElementById('promoVideo');
const videoFallback = document.getElementById('videoFallback');

if (playBtn && promoVideo) {
  playBtn.addEventListener('click', () => {
    const hasSource = promoVideo.currentSrc || promoVideo.querySelector('source')?.src;
    if (hasSource) {
      promoVideo.play().then(() => {
        playBtn.classList.add('is-playing');
      }).catch(() => {
        // no playable source available, keep fallback visuals
        videoFallback.style.display = 'block';
      });
    }
  });
  promoVideo.addEventListener('pause', () => playBtn.classList.remove('is-playing'));
  promoVideo.addEventListener('ended', () => playBtn.classList.remove('is-playing'));
}

// ===================== MARQUEE ARROWS =====================
const marqueeTrack = document.getElementById('marqueeTrack');
const leftArrow = document.querySelector('.marquee-arrow.left');
const rightArrow = document.querySelector('.marquee-arrow.right');
const trackWrap = document.querySelector('.marquee-track-wrap');

if (leftArrow && rightArrow && trackWrap) {
  leftArrow.addEventListener('click', () => {
    trackWrap.scrollBy({ left: -220, behavior: 'smooth' });
  });
  rightArrow.addEventListener('click', () => {
    trackWrap.scrollBy({ left: 220, behavior: 'smooth' });
  });
}

// ===================== ROTATING DOT-MATRIX GLOBE =====================
(function initGlobe() {
  const canvas = document.getElementById('globeCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const DPR = Math.min(window.devicePixelRatio || 1, 2);

  let size = canvas.clientWidth;
  function resize() {
    size = canvas.clientWidth;
    canvas.width = size * DPR;
    canvas.height = size * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }
  window.addEventListener('resize', resize);

  // Generate points on a sphere (Fibonacci sphere) for even distribution
  const POINT_COUNT = 900;
  const points = [];
  const golden = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < POINT_COUNT; i++) {
    const y = 1 - (i / (POINT_COUNT - 1)) * 2;
    const radiusAtY = Math.sqrt(1 - y * y);
    const theta = golden * i;
    const x = Math.cos(theta) * radiusAtY;
    const z = Math.sin(theta) * radiusAtY;
    points.push({ x, y, z });
  }

  // rough landmass mask using simple lat/long sine bands to suggest continents (stylised, not geographically precise)
  function isLand(x, y, z) {
    const lat = Math.asin(y);
    const lon = Math.atan2(z, x);
    const n = Math.sin(lon * 3 + lat * 2) + Math.sin(lat * 5) * 0.5 + Math.sin(lon * 1.3) * 0.4;
    return n > 0.35;
  }

  let angle = 0;
  let tilt = -0.28;
  let running = true;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function draw() {
    if (!running) return;
    ctx.clearRect(0, 0, size, size);
    const cx = size / 2;
    const cy = size / 2;
    const R = size * 0.36;

    const cosA = Math.cos(angle), sinA = Math.sin(angle);
    const cosT = Math.cos(tilt), sinT = Math.sin(tilt);

    // outer glow ring
    const grad = ctx.createRadialGradient(cx, cy, R * 0.2, cx, cy, R * 1.15);
    grad.addColorStop(0, 'rgba(46,111,242,0.10)');
    grad.addColorStop(1, 'rgba(46,111,242,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cx, cy, R * 1.15, 0, Math.PI * 2);
    ctx.fill();

    // sort points back-to-front
    const projected = points.map(p => {
      // rotate around Y (spin)
      let x = p.x * cosA - p.z * sinA;
      let z = p.x * sinA + p.z * cosA;
      let y = p.y;
      // tilt around X
      let y2 = y * cosT - z * sinT;
      let z2 = y * sinT + z * cosT;
      return { x, y: y2, z: z2, land: isLand(p.x, p.y, p.z) };
    });
    projected.sort((a, b) => a.z - b.z);

    projected.forEach(p => {
      const scale = (p.z + 1.6) / 2.6;
      const px = cx + p.x * R;
      const py = cy + p.y * R;
      const depth = (p.z + 1) / 2;
      const alpha = 0.18 + depth * 0.65;
      const dotSize = 0.9 + depth * 1.6;

      if (p.land) {
        ctx.fillStyle = `rgba(239,195,88,${alpha})`;
      } else {
        ctx.fillStyle = `rgba(91,141,239,${alpha * 0.85})`;
      }
      ctx.beginPath();
      ctx.arc(px, py, dotSize * (size / 560), 0, Math.PI * 2);
      ctx.fill();
    });

    // thin outer ring
    ctx.strokeStyle = 'rgba(91,141,239,0.25)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.stroke();

    angle += reduceMotion ? 0 : 0.0028;
    requestAnimationFrame(draw);
  }

  resize();
  requestAnimationFrame(draw);

  document.addEventListener('visibilitychange', () => {
    running = !document.hidden;
    if (running) requestAnimationFrame(draw);
  });
})();
